import React, { useEffect, useState } from "react";
import {
  AppState,
  ScrollView,
  Text,
  View,
  Alert,
  BackHandler,
} from "react-native";
import { SafeAreaProvider, SafeAreaView } from "react-native-safe-area-context";
import { StatusBar } from "expo-status-bar";
import { Session, SupabaseClient } from "@supabase/supabase-js";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { Config, loadConfig, saveConfig, makeClient } from "./src/client";
import { Button, Field, Busy, s, C } from "./src/ui";
import Auth from "./src/Auth";
import Home from "./src/Home";
export default function App() {
  const [config, setConfig] = useState<Config | null>(null),
    [loading, setLoading] = useState(true);
  useEffect(() => {
    loadConfig()
      .then(setConfig)
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);
  return (
    <SafeAreaProvider>
      <SafeAreaView style={s.fill}>
        <StatusBar style="light" />
        {loading ? (
          <Busy />
        ) : config ? (
          <Connected
            key={config.url + config.key}
            config={config}
            reset={async () => {
              await AsyncStorage.removeItem("wasla.config");
              setConfig(null);
            }}
          />
        ) : (
          <Setup done={setConfig} />
        )}
      </SafeAreaView>
    </SafeAreaProvider>
  );
}
function Setup({ done }: { done: (c: Config) => void }) {
  const [url, setUrl] = useState(""),
    [key, setKey] = useState(""),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  return (
    <ScrollView contentContainerStyle={[s.page, { paddingTop: 60 }]}>
      <Text style={s.tag}>WASLA / FIRST CONNECTION</Text>
      <Text style={s.title}>وصلة</Text>
      <Text style={s.subtitle}>
        مرّة وحدة، منربط التطبيق بالخدمة الخاصة فيك.{"\n"}ما عندك حساب خدمة بعد؟
        اتبع دليل البداية المرفق بالمشروع.
      </Text>
      <View style={s.card}>
        <Text style={[s.text, { fontWeight: "700" }]}>
          بيانات المشروع العامة
        </Text>
        <Field
          placeholder="https://project.supabase.co"
          autoCapitalize="none"
          value={url}
          onChangeText={setUrl}
          style={{ textAlign: "left" }}
        />
        <Field
          placeholder="Publishable key / anon key"
          autoCapitalize="none"
          value={key}
          onChangeText={setKey}
          multiline
          style={{ textAlign: "left", maxHeight: 130 }}
        />
        <Text style={s.subtitle}>
          حط الرابط والمفتاح العام فقط. لا تستخدم كلمة مرور الحساب أو المفتاح
          السري.
        </Text>
      </View>
      {!!error && <Text style={s.error}>{error}</Text>}
      <Button
        title={busy ? "عم نتأكّد…" : "ربط وصلة"}
        disabled={busy}
        onPress={async () => {
          setBusy(true);
          setError("");
          try {
            const c = { url: url.trim().replace(/\/$/, ""), key: key.trim() };
            await saveConfig(c);
            done(c);
          } catch (e: any) {
            setError(e.message);
          } finally {
            setBusy(false);
          }
        }}
      />
    </ScrollView>
  );
}
function Connected({
  config,
  reset,
}: {
  config: Config;
  reset: () => Promise<void>;
}) {
  const [db] = useState<SupabaseClient>(() => makeClient(config));
  const [session, setSession] = useState<Session | null>(null),
    [loading, setLoading] = useState(true),
    [error, setError] = useState("");
  useEffect(() => {
    let live = true;
    db.auth.getSession().then(({ data, error }) => {
      if (!live) return;
      if (error) setError(error.message);
      setSession(data.session);
      setLoading(false);
    });
    const {
      data: { subscription },
    } = db.auth.onAuthStateChange((event, value) => {
      if (event !== "PASSWORD_RECOVERY") {
        setSession(value);
        setLoading(false);
      }
    });
    const app = AppState.addEventListener("change", (state) =>
      state === "active"
        ? db.auth.startAutoRefresh()
        : db.auth.stopAutoRefresh(),
    );
    db.auth.startAutoRefresh();
    return () => {
      live = false;
      subscription.unsubscribe();
      app.remove();
      db.auth.stopAutoRefresh();
      db.removeAllChannels();
    };
  }, [db]);
  if (loading) return <Busy />;
  if (error)
    return (
      <View style={s.page}>
        <Text style={s.error}>{error}</Text>
        <Button
          title="إعادة الاتصال"
          onPress={() => {
            void reset();
          }}
        />
      </View>
    );
  return session ? (
    <Home db={db} session={session} />
  ) : (
    <Auth
      db={db}
      onReset={() => {
        void reset();
      }}
    />
  );
}
