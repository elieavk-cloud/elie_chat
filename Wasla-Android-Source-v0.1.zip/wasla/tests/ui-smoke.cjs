const { chromium } = require("playwright");
const assert = require("node:assert/strict");
(async () => {
  const fs = require("node:fs"),
    path = require("node:path"),
    http = require("node:http");
  const root = path.resolve(__dirname, "../web-preview");
  const server = http.createServer((req, res) => {
    let p = path.join(root, decodeURIComponent(req.url.split("?")[0]));
    if (p.endsWith("/")) p += "index.html";
    try {
      res.setHeader(
        "Content-Type",
        p.endsWith(".js")
          ? "text/javascript"
          : p.endsWith(".html")
            ? "text/html"
            : "application/octet-stream",
      );
      res.end(fs.readFileSync(p));
    } catch {
      res.statusCode = 404;
      res.end();
    }
  });
  await new Promise((resolve) => server.listen(8766, "127.0.0.1", resolve));
  const browser = await chromium.launch({
    headless: true,
    executablePath: process.env.PLAYWRIGHT_EXECUTABLE_PATH || undefined,
    args: ["--no-sandbox"],
  });
  const page = await browser.newPage({
    viewport: { width: 393, height: 852 },
    deviceScaleFactor: 1,
  });
  const exceptions = [];
  page.on("pageerror", (e) => exceptions.push(e.message));
  const now = new Date().toISOString(),
    a = "11111111-1111-4111-8111-111111111111",
    b = "22222222-2222-4222-8222-222222222222",
    r = "33333333-3333-4333-8333-333333333333";
  const profiles = [
    {
      id: a,
      display_name: "إيلي",
      handle: "elie_demo",
      about: "أهلاً في وصلة",
    },
    { id: b, display_name: "كريم", handle: "karim_demo", about: "" },
  ];
  const room = {
    id: r,
    title: "",
    is_group: false,
    owner_id: a,
    updated_at: now,
    members: profiles.map((p) => ({
      user_id: p.id,
      last_read: now,
      profiles: p,
    })),
  };
  let messages = [
    {
      id: "44444444-4444-4444-8444-444444444444",
      room_id: r,
      sender_id: b,
      body: "مرحبا إيلي! كيفك؟ 👋",
      kind: "text",
      file_path: null,
      reply_to: null,
      created_at: now,
      edited_at: null,
      deleted: false,
      profiles: profiles[1],
      reactions: [],
    },
  ];
  await page.route("https://demo.supabase.co/**", async (route) => {
    let data = [];
    const url = new URL(route.request().url());
    const method = route.request().method();
    if (method === "OPTIONS")
      return route.fulfill({
        status: 200,
        headers: {
          "access-control-allow-origin": "*",
          "access-control-allow-headers": "*",
        },
        body: "",
      });
    if (url.pathname.includes("/auth/v1/token"))
      data = {
        access_token: "demo.jwt.token",
        refresh_token: "demo-refresh",
        expires_in: 3600,
        token_type: "bearer",
        user: {
          id: a,
          email: "elie@example.test",
          aud: "authenticated",
          role: "authenticated",
          user_metadata: {},
          app_metadata: {},
          created_at: now,
        },
      };
    else if (url.pathname === "/rest/v1/rooms") data = [room];
    else if (url.pathname === "/rest/v1/profiles") data = profiles[0];
    else if (url.pathname === "/rest/v1/messages") data = messages;
    else if (url.pathname.endsWith("/rpc/send_message")) {
      const x = route.request().postDataJSON();
      messages = [
        {
          ...messages[0],
          id: x.message_id,
          sender_id: a,
          body: x.b,
          profiles: profiles[0],
        },
        ...messages,
      ];
      data = x.message_id;
    } else if (url.pathname.endsWith("/rpc/mark_read")) data = null;
    else if (url.pathname === "/auth/v1/user")
      data = { id: a, email: "elie@example.test" };
    return route.fulfill({
      status: 200,
      contentType: "application/json",
      headers: { "access-control-allow-origin": "*" },
      body: JSON.stringify(data),
    });
  });
  await page.goto("http://127.0.0.1:8766");
  await page
    .getByPlaceholder("https://project.supabase.co")
    .fill("https://demo.supabase.co");
  await page
    .getByPlaceholder("Publishable key / anon key")
    .fill("sb_publishable_ui_test_only");
  await page.getByRole("button", { name: "ربط وصلة", exact: true }).click();
  await page.getByText("أهلاً في وصلة", { exact: true }).waitFor();
  await page.screenshot({
    path: path.resolve(__dirname, "../previews/login.png"),
  });
  await page
    .getByPlaceholder("الإيميل", { exact: true })
    .fill("elie@example.test");
  await page
    .getByPlaceholder("كلمة المرور", { exact: true })
    .fill("only-a-local-ui-test");
  await page.getByRole("button", { name: "دخول", exact: true }).click();
  await page.getByText("كريم", { exact: true }).waitFor();
  await page.screenshot({
    path: path.resolve(__dirname, "../previews/chats.png"),
  });
  await page.getByText("كريم", { exact: true }).click();
  await page.getByText("مرحبا إيلي! كيفك؟ 👋", { exact: true }).waitFor();
  await page.getByPlaceholder("اكتب رسالة…").fill("تمام! منجرّب وصلة اليوم 💚");
  await page.getByRole("button", { name: "إرسال", exact: true }).click();
  await page.getByText("تمام! منجرّب وصلة اليوم 💚", { exact: true }).waitFor();
  await page.screenshot({
    path: path.resolve(__dirname, "../previews/conversation.png"),
  });
  assert.deepEqual(exceptions, []);
  assert.equal(messages.length, 2);
  console.log(
    "PASS mobile viewport: setup, login, list, open chat, send text. API responses mocked; no hosted backend tested.",
  );
  await browser.close();
  server.close();
})().catch((e) => {
  console.error(e);
  process.exit(1);
});
