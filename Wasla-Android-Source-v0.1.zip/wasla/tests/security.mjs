import { PGlite } from "@electric-sql/pglite";
import { readFileSync } from "node:fs";
import assert from "node:assert/strict";
const db = new PGlite();
await db.exec(`create role anon; create role authenticated;
create schema auth; create schema storage;
create table auth.users(id uuid primary key,raw_user_meta_data jsonb default '{}');
create function auth.uid() returns uuid language sql stable as $$select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid$$;
grant usage on schema auth,public,storage to authenticated,anon;
grant execute on function auth.uid() to authenticated,anon;
create table storage.buckets(id text primary key,name text,public boolean,file_size_limit bigint);
create table storage.objects(id uuid default gen_random_uuid() primary key,bucket_id text,name text);
alter table storage.objects enable row level security;
grant select,insert,delete on storage.objects to authenticated;
create function storage.foldername(text) returns text[] language sql immutable as $$select (string_to_array($1,'/'))[1:array_length(string_to_array($1,'/'),1)-1]$$;
create publication supabase_realtime;`);
await db.exec(
  readFileSync(new URL("../supabase/schema.sql", import.meta.url), "utf8"),
);
const a = "11111111-1111-4111-8111-111111111111",
  b = "22222222-2222-4222-8222-222222222222",
  c = "33333333-3333-4333-8333-333333333333";
for (const [id, name] of [
  [a, "alice"],
  [b, "bob"],
  [c, "cara"],
]) {
  await db.query(
    "insert into auth.users(id,raw_user_meta_data) values($1,$2)",
    [id, JSON.stringify({ display_name: name })],
  );
  await db.query("update profiles set handle=$1 where id=$2", [name, id]);
}
async function user(id, fn) {
  await db.exec("set role authenticated");
  await db.query("select set_config('request.jwt.claim.sub',$1,false)", [id]);
  try {
    return await fn();
  } finally {
    await db.exec("reset role");
  }
}
async function denied(fn, label) {
  await assert.rejects(fn, undefined, label);
  console.log("PASS denied:", label);
}
const room = await user(a, async () => {
  const r = await db.query("select create_room(array['bob'],'') as id");
  return r.rows[0].id;
});
await user(a, async () => {
  assert.equal(
    (await db.query("select create_room(array['bob'],'') as id")).rows[0].id,
    room,
  );
});
console.log("PASS direct conversation idempotency");
const mid = await user(a, async () => {
  const r = await db.query("select send_message($1,'hello') as id", [room]);
  return r.rows[0].id;
});
await user(b, async () => {
  assert.equal(
    (await db.query("select body from messages")).rows[0].body,
    "hello",
  );
});
await user(c, async () => {
  assert.equal((await db.query("select * from messages")).rows.length, 0);
  assert.equal((await db.query("select * from members")).rows.length, 0);
  assert.equal((await db.query("select * from rooms")).rows.length, 0);
  assert.equal((await db.query("select * from profiles")).rows.length, 1);
});
console.log(
  "PASS non-members cannot read conversations, membership or other profiles",
);
await denied(
  () => user(c, () => db.query("select send_message($1,'intrusion')", [room])),
  "non-member sends",
);
await denied(
  () =>
    user(b, () =>
      db.query(
        "insert into messages(room_id,sender_id,body) values($1,$2,'spoof')",
        [room, a],
      ),
    ),
  "spoofed sender",
);
await denied(
  () =>
    user(b, () =>
      db.query("update members set user_id=$1 where room_id=$2", [c, room]),
    ),
  "membership escalation",
);
await denied(
  () => user(b, () => db.query("select edit_message($1,'tampered')", [mid])),
  "edit somebody else’s message",
);
await user(a, () => db.query("select edit_message($1,'updated')", [mid]));
await user(b, async () => {
  checkCount(
    await db.query("select body from messages where id=$1", [mid]),
    "updated",
  );
  await db.query("select mark_read($1)", [room]);
});
function checkCount(r, body) {
  assert.equal(r.rows[0].body, body);
}
const path = `${room}/${a}/test.jpg`;
await user(a, () =>
  db.query(
    "insert into storage.objects(bucket_id,name) values('chat-media',$1)",
    [path],
  ),
);
await user(b, async () => {
  assert.equal(
    (await db.query("select * from storage.objects")).rows.length,
    1,
  );
});
await user(c, async () => {
  assert.equal(
    (await db.query("select * from storage.objects")).rows.length,
    0,
  );
});
await denied(
  () =>
    user(c, () =>
      db.query(
        "insert into storage.objects(bucket_id,name) values('chat-media',$1)",
        [`${room}/${c}/x.jpg`],
      ),
    ),
  "non-member media upload",
);
await denied(
  () =>
    user(b, () =>
      db.query("select send_message($1,'','image',$2)", [room, path]),
    ),
  "send another uploader’s file",
);
await user(a, () =>
  db.query("select send_message($1,'','image',$2)", [room, path]),
);
console.log("PASS private attachments and owner paths");
await user(b, () => db.query("insert into blocks values($1,$2)", [b, a]));
await denied(
  () => user(a, () => db.query("select send_message($1,'blocked')", [room])),
  "blocked sender",
);
await denied(
  () => user(a, () => db.query("select edit_message($1,'bypass')", [mid])),
  "edit to bypass block",
);
await user(b, () => db.query("delete from blocks where blocker=$1", [b]));
await user(a, () => db.query("select send_message($1,'unblocked')", [room]));
const group = await user(a, async () => {
  const r = await db.query(
    "select create_room(array['bob','cara'],'Friends') as id",
  );
  return r.rows[0].id;
});
await denied(
  () => user(b, () => db.query("select manage_group($1,'cara',true)", [group])),
  "non-admin removal",
);
await user(a, () => db.query("select manage_group($1,'cara',true)", [group]));
await user(c, async () =>
  assert.equal(
    (await db.query("select * from rooms where id=$1", [group])).rows.length,
    0,
  ),
);
await user(a, () =>
  db.query("insert into statuses(user_id,body) values($1,'today')", [a]),
);
await user(b, async () =>
  assert.equal((await db.query("select * from statuses")).rows.length, 1),
);
await user(c, async () =>
  assert.equal((await db.query("select * from statuses")).rows.length, 0),
);
await denied(
  () =>
    user(b, () =>
      db.query(
        "insert into statuses(user_id,body,created_at) values($1,'forever',now()+interval '1 year')",
        [b],
      ),
    ),
  "status timestamp forgery",
);
await user(a, () => db.query("select edit_message($1,null)", [mid]));
await user(b, async () => {
  const r = await db.query("select * from messages where id=$1", [mid]);
  assert.equal(r.rows[0].deleted, true);
  assert.equal(r.rows[0].body, "");
});
await db.exec("set role anon");
await denied(
  () => db.query("select create_room(array['alice'],'')"),
  "anonymous RPC",
);
await db.exec("reset role");
console.log(
  "PASS schema execution, reads, edits, receipts, blocks, groups, statuses, tombstones",
);
await db.close();
