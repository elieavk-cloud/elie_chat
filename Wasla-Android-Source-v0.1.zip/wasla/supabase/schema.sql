-- Wasla v0.1: run ONCE in a NEW Supabase project. No email addresses in public tables.
begin;
create table public.profiles (
 id uuid primary key references auth.users on delete cascade,
 handle text unique not null check(handle ~ '^[a-z0-9_]{3,24}$'),
 display_name text not null check(char_length(display_name) between 1 and 60),
 about text not null default '' check(char_length(about)<=160)
);
create table public.rooms (
 id uuid primary key default gen_random_uuid(), title text not null default '' check(char_length(title)<=80),
 is_group boolean not null default false, owner_id uuid references public.profiles,
 dm_key text unique, created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.members (
 room_id uuid references public.rooms on delete cascade, user_id uuid references public.profiles on delete cascade,
 last_read timestamptz not null default now(), primary key(room_id,user_id)
);
create table public.blocks (
 blocker uuid references public.profiles on delete cascade, blocked uuid references public.profiles on delete cascade,
 primary key(blocker,blocked), check(blocker<>blocked)
);
create table public.messages (
 id uuid primary key default gen_random_uuid(), room_id uuid not null references public.rooms on delete cascade,
 sender_id uuid not null references public.profiles, body text not null default '' check(char_length(body)<=4000),
 kind text not null default 'text' check(kind in ('text','image','video','audio','file')),
 file_path text, file_name text, reply_to uuid references public.messages,
 created_at timestamptz not null default now(), edited_at timestamptz, deleted boolean not null default false,
 check(kind='text' or file_path is not null or deleted)
);
create index messages_room_date on public.messages(room_id,created_at desc);
create index members_user on public.members(user_id,room_id);
create table public.reactions (
 message_id uuid references public.messages on delete cascade, user_id uuid references public.profiles on delete cascade,
 emoji text not null check(emoji in ('❤️','👍','😂','😮','😢')), primary key(message_id,user_id)
);
create table public.statuses (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references public.profiles on delete cascade,
 body text not null check(char_length(body) between 1 and 500), created_at timestamptz not null default now()
);
create function public.is_member(r uuid) returns boolean language sql stable security definer set search_path='' as $$
 select exists(select 1 from public.members where room_id=r and user_id=auth.uid());
$$;
create function public.is_blocked(other uuid) returns boolean language sql stable security definer set search_path='' as $$
 select exists(select 1 from public.blocks where (blocker=auth.uid() and blocked=other) or (blocked=auth.uid() and blocker=other));
$$;
create function public.shares_room(other uuid) returns boolean language sql stable security definer set search_path='' as $$
 select other=auth.uid() or exists(select 1 from public.members a join public.members b using(room_id) where a.user_id=auth.uid() and b.user_id=other);
$$;
create function public.can_send(r uuid) returns boolean language sql stable security definer set search_path='' as $$
 select public.is_member(r) and not exists(select 1 from public.members m where m.room_id=r and public.is_blocked(m.user_id));
$$;
create function public.on_signup() returns trigger language plpgsql security definer set search_path='' as $$
begin
 insert into public.profiles(id,handle,display_name) values(new.id,'u_'||substr(replace(new.id::text,'-',''),1,20),coalesce(nullif(left(new.raw_user_meta_data->>'display_name',60),''),'عضو جديد'));
 return new;
end; $$;
create trigger signup_profile after insert on auth.users for each row execute function public.on_signup();

alter table public.profiles enable row level security;
alter table public.rooms enable row level security;
alter table public.members enable row level security;
alter table public.blocks enable row level security;
alter table public.messages enable row level security;
alter table public.reactions enable row level security;
alter table public.statuses enable row level security;
create policy profiles_read on public.profiles for select to authenticated using(public.shares_room(id));
create policy profiles_edit on public.profiles for update to authenticated using(id=auth.uid()) with check(id=auth.uid());
create policy rooms_read on public.rooms for select to authenticated using(public.is_member(id));
create policy members_read on public.members for select to authenticated using(public.is_member(room_id));
create policy blocks_read on public.blocks for select to authenticated using(blocker=auth.uid());
create policy blocks_add on public.blocks for insert to authenticated with check(blocker=auth.uid());
create policy blocks_remove on public.blocks for delete to authenticated using(blocker=auth.uid());
create policy messages_read on public.messages for select to authenticated using(public.is_member(room_id));
create policy reactions_read on public.reactions for select to authenticated using(exists(select 1 from public.messages m where m.id=message_id and public.is_member(m.room_id)));
create policy reactions_add on public.reactions for insert to authenticated with check(user_id=auth.uid() and exists(select 1 from public.messages m where m.id=message_id and not m.deleted and public.can_send(m.room_id)));
create policy reactions_edit on public.reactions for update to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid() and exists(select 1 from public.messages m where m.id=message_id and not m.deleted and public.can_send(m.room_id)));
create policy reactions_remove on public.reactions for delete to authenticated using(user_id=auth.uid());
create policy statuses_read on public.statuses for select to authenticated using(created_at>now()-interval '24 hours' and public.shares_room(user_id) and not public.is_blocked(user_id));
create policy statuses_add on public.statuses for insert to authenticated with check(user_id=auth.uid());
create policy statuses_remove on public.statuses for delete to authenticated using(user_id=auth.uid());
revoke all on public.profiles,public.rooms,public.members,public.blocks,public.messages,public.reactions,public.statuses from anon,authenticated;
grant select on public.profiles,public.rooms,public.members,public.blocks,public.messages,public.reactions,public.statuses to authenticated;
grant update(handle,display_name,about) on public.profiles to authenticated;
grant insert,delete on public.blocks to authenticated;
grant insert,update(emoji),delete on public.reactions to authenticated;
grant insert(user_id,body),delete on public.statuses to authenticated;

create function public.create_room(handles text[], group_title text default '') returns uuid language plpgsql security definer set search_path='' as $$
declare ids uuid[]; target uuid; r uuid; k text; grouped boolean:=length(trim(group_title))>0;
begin
 if auth.uid() is null then raise exception 'Not authenticated'; end if;
 if cardinality(handles)<1 or cardinality(handles)>31 then raise exception 'Choose 1 to 31 members'; end if;
 select array_agg(distinct id) into ids from public.profiles where handle=any(handles) and id<>auth.uid();
 if coalesce(cardinality(ids),0)<>cardinality(handles) then raise exception 'Check usernames; do not include yourself or duplicates'; end if;
 if not grouped and cardinality(ids)<>1 then raise exception 'Group title required'; end if;
 foreach target in array ids loop
  if public.is_blocked(target) then raise exception 'Cannot create this conversation'; end if;
 end loop;
 if not grouped then
  k:=least(auth.uid()::text,ids[1]::text)||':'||greatest(auth.uid()::text,ids[1]::text);
  perform pg_advisory_xact_lock(hashtextextended(k,0));
  select id into r from public.rooms where dm_key=k;
  if r is not null then return r; end if;
 end if;
 insert into public.rooms(title,is_group,owner_id,dm_key) values(trim(group_title),grouped,auth.uid(),k) returning id into r;
 insert into public.members(room_id,user_id) values(r,auth.uid());
 insert into public.members(room_id,user_id) select r,unnest(ids);
 return r;
end; $$;
create function public.send_message(r uuid, b text default '', k text default 'text', path text default null, filename text default null, reply uuid default null, message_id uuid default gen_random_uuid()) returns uuid language plpgsql security definer set search_path='' as $$
begin
 if not public.can_send(r) then raise exception 'Sending is unavailable; check membership or blocked contacts'; end if;
 if reply is not null and not exists(select 1 from public.messages where id=reply and room_id=r) then raise exception 'Invalid reply'; end if;
 if k='text' and length(trim(b))=0 then raise exception 'Empty message'; end if;
 if k<>'text' and (path is null or split_part(path,'/',1)<>r::text or split_part(path,'/',2)<>auth.uid()::text or not exists(select 1 from storage.objects where bucket_id='chat-media' and name=path)) then raise exception 'Invalid attachment'; end if;
 if exists(select 1 from public.messages where id=message_id and sender_id=auth.uid() and room_id=r) then return message_id; end if;
 insert into public.messages(id,room_id,sender_id,body,kind,file_path,file_name,reply_to) values(message_id,r,auth.uid(),trim(b),k,path,left(filename,160),reply);
 update public.rooms set updated_at=now() where id=r;
 return message_id;
end; $$;
create function public.edit_message(m uuid, b text default null) returns void language plpgsql security definer set search_path='' as $$
begin
 if not exists(select 1 from public.messages where id=m and sender_id=auth.uid() and not deleted and public.is_member(room_id)) then raise exception 'Message not editable'; end if;
 if b is null then
  update public.messages set deleted=true,body='',file_path=null,file_name=null,edited_at=now() where id=m;
  delete from public.reactions where message_id=m;
 else
  if not exists(select 1 from public.messages where id=m and public.can_send(room_id)) then raise exception 'Sending unavailable'; end if;
  if length(trim(b))=0 then raise exception 'Empty message'; end if;
  update public.messages set body=trim(b),edited_at=now() where id=m;
 end if;
end; $$;
create function public.mark_read(r uuid) returns void language sql security definer set search_path='' as $$
 update public.members set last_read=now() where room_id=r and user_id=auth.uid();
$$;
create function public.manage_group(r uuid, member_handle text, remove_member boolean default false) returns void language plpgsql security definer set search_path='' as $$
declare target uuid;
begin
 if not exists(select 1 from public.rooms where id=r and is_group and owner_id=auth.uid()) then raise exception 'Group owner only'; end if;
 select id into target from public.profiles where handle=member_handle;
 if target is null or target=auth.uid() then raise exception 'Invalid member'; end if;
 if remove_member then delete from public.members where room_id=r and user_id=target;
 else
  if public.is_blocked(target) then raise exception 'Contact unavailable'; end if;
  if (select count(*) from public.members where room_id=r)>=32 then raise exception 'Group limit reached'; end if;
  insert into public.members(room_id,user_id) values(r,target) on conflict do nothing;
 end if;
end; $$;
-- Private media: UUID room / UUID uploader / random filename; short-lived signed URLs.
insert into storage.buckets(id,name,public,file_size_limit) values('chat-media','chat-media',false,6291456);
create policy media_upload on storage.objects for insert to authenticated with check(bucket_id='chat-media' and (storage.foldername(name))[2]=auth.uid()::text and public.can_send(((storage.foldername(name))[1])::uuid));
create policy media_read on storage.objects for select to authenticated using(bucket_id='chat-media' and public.is_member(((storage.foldername(name))[1])::uuid));
create policy media_delete on storage.objects for delete to authenticated using(bucket_id='chat-media' and (storage.foldername(name))[2]=auth.uid()::text);
-- Default Postgres EXECUTE is PUBLIC. Explicitly scope every RPC.
revoke execute on function public.on_signup() from public,anon,authenticated;
revoke execute on function public.is_member(uuid),public.is_blocked(uuid),public.shares_room(uuid),public.can_send(uuid),public.create_room(text[],text),public.send_message(uuid,text,text,text,text,uuid,uuid),public.edit_message(uuid,text),public.mark_read(uuid),public.manage_group(uuid,text,boolean) from public,anon;
grant execute on function public.is_member(uuid),public.is_blocked(uuid),public.shares_room(uuid),public.can_send(uuid),public.create_room(text[],text),public.send_message(uuid,text,text,text,text,uuid,uuid),public.edit_message(uuid,text),public.mark_read(uuid),public.manage_group(uuid,text,boolean) to authenticated;
alter publication supabase_realtime add table public.messages,public.rooms,public.members,public.reactions,public.statuses;
commit;
