import React, { useCallback, useEffect, useState } from "react";
import {
  View,
  Text,
  FlatList,
  ScrollView,
  Pressable,
  Modal,
  Alert,
  AppState,
  BackHandler,
} from "react-native";
import { SupabaseClient, Session } from "@supabase/supabase-js";
import { Profile, Room, Story, check, rooms, roomTitle } from "./client";
import { Avatar, Button, Field, Busy, C, s } from "./ui";
import Chat from "./Chat";
export default function Home({
  db,
  session,
}: {
  db: SupabaseClient;
  session: Session;
}) {
  const uid = session.user.id;
  const [tab, setTab] = useState<"chats" | "status" | "profile">("chats"),
    [items, setItems] = useState<Room[]>([]),
    [profile, setProfile] = useState<Profile | null>(null),
    [active, setActive] = useState<Room | null>(null),
    [loading, setLoading] = useState(true),
    [error, setError] = useState(""),
    [search, setSearch] = useState(""),
    [creating, setCreating] = useState(false),
    [handles, setHandles] = useState(""),
    [groupTitle, setGroupTitle] = useState(""),
    [group, setGroup] = useState(false),
    [busy, setBusy] = useState(false);
  const refresh = useCallback(async () => {
    try {
      const [r, p] = await Promise.all([
        rooms(db),
        db.from("profiles").select("*").eq("id", uid).single(),
      ]);
      check(p);
      setItems(r);
      setProfile(p.data);
      setError("");
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, [db, uid]);
  useEffect(() => {
    void refresh();
    let timer: ReturnType<typeof setTimeout>;
    const changed = () => {
      clearTimeout(timer);
      timer = setTimeout(() => void refresh(), 300);
    };
    const ch = db
      .channel("home-" + uid)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "rooms" },
        changed,
      )
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "members" },
        changed,
      )
      .subscribe((status) => {
        if (status === "SUBSCRIBED") changed();
        if (status === "CHANNEL_ERROR")
          setError("الاتصال المباشر انقطع. اسحب لتحديث المحادثات.");
      });
    const app = AppState.addEventListener("change", (x) => {
      if (x === "active") changed();
    });
    return () => {
      clearTimeout(timer);
      void db.removeChannel(ch);
      app.remove();
    };
  }, [refresh]);
  useEffect(() => {
    const h = BackHandler.addEventListener("hardwareBackPress", () => {
      if (active) {
        setActive(null);
        return true;
      }
      if (creating) {
        setCreating(false);
        return true;
      }
      if (tab !== "chats") {
        setTab("chats");
        return true;
      }
      return false;
    });
    return () => h.remove();
  }, [active, creating, tab]);
  async function create() {
    setBusy(true);
    try {
      const list = handles
        .toLowerCase()
        .split(/[,،\s]+/)
        .map((x) => x.trim().replace(/^@/, ""))
        .filter(Boolean);
      if (group && !groupTitle.trim()) throw Error("سمّي المجموعة");
      const r = check(
        await db.rpc("create_room", {
          handles: list,
          group_title: group ? groupTitle : "",
        }),
      );
      const all = await rooms(db);
      setItems(all);
      setActive(all.find((x) => x.id === r.data) || null);
      setCreating(false);
      setHandles("");
      setGroupTitle("");
    } catch (e: any) {
      Alert.alert("تعذّر إنشاء المحادثة", e.message);
    } finally {
      setBusy(false);
    }
  }
  if (active)
    return (
      <Chat
        key={active.id}
        db={db}
        room={items.find((r) => r.id === active.id) || active}
        uid={uid}
        back={() => {
          setActive(null);
          void refresh();
        }}
      />
    );
  return (
    <View style={s.fill}>
      <View style={[s.header, s.row]}>
        <Pressable onPress={() => setTab("profile")} accessibilityLabel="حسابي">
          <Avatar name={profile?.display_name || "و"} />
        </Pressable>
        <View style={{ flex: 1 }}>
          <Text style={s.tag}>STAY CLOSE</Text>
          <Text style={s.title}>وصلة</Text>
        </View>
      </View>
      <View style={[s.row, { padding: 18 }]}>
        {(["profile", "status", "chats"] as const).map((t) => (
          <Pressable
            key={t}
            onPress={() => setTab(t)}
            style={{
              flex: 1,
              padding: 12,
              borderRadius: 14,
              backgroundColor: tab === t ? C.mint : C.panel,
            }}
          >
            <Text
              style={{
                textAlign: "center",
                fontWeight: "700",
                color: tab === t ? C.dark : C.muted,
              }}
            >
              {{ chats: "الدردشات", status: "الحالات", profile: "حسابي" }[t]}
            </Text>
          </Pressable>
        ))}
      </View>
      {!!error && <Text style={s.error}>{error}</Text>}
      {tab === "chats" && (
        <>
          <View style={{ paddingHorizontal: 20, paddingBottom: 14 }}>
            <Field
              placeholder="ابحث عن محادثة…"
              value={search}
              onChangeText={setSearch}
            />
          </View>
          {loading ? (
            <Busy />
          ) : (
            <FlatList
              data={items.filter((r) =>
                roomTitle(r, uid).toLowerCase().includes(search.toLowerCase()),
              )}
              keyExtractor={(x) => x.id}
              onRefresh={refresh}
              refreshing={loading}
              contentContainerStyle={{
                paddingHorizontal: 20,
                paddingBottom: 100,
                flexGrow: 1,
              }}
              ListEmptyComponent={
                <View style={s.center}>
                  <Avatar name="و" size={86} />
                  <Text style={[s.title, { fontSize: 23, marginTop: 20 }]}>
                    أول «مرحبا» من عندك
                  </Text>
                  <Text style={s.subtitle}>
                    اضغط محادثة جديدة وضيف رفيقك باسم المستخدم.
                  </Text>
                </View>
              }
              renderItem={({ item: r }) => (
                <Pressable
                  onPress={() => setActive(r)}
                  style={[
                    s.row,
                    {
                      paddingVertical: 18,
                      borderBottomWidth: 1,
                      borderColor: C.line,
                    },
                  ]}
                >
                  <Text style={{ color: C.muted, fontSize: 11 }}>
                    {new Date(r.updated_at).toLocaleDateString("ar-LB", {
                      month: "short",
                      day: "numeric",
                    })}
                  </Text>
                  <View style={{ flex: 1, gap: 5 }}>
                    <Text style={[s.text, { fontWeight: "700", fontSize: 17 }]}>
                      {roomTitle(r, uid)}
                    </Text>
                    <Text style={s.subtitle}>
                      {r.is_group
                        ? `مجموعة · ${r.members.length} أعضاء`
                        : "محادثة خاصة"}
                    </Text>
                  </View>
                  <Avatar name={roomTitle(r, uid)} />
                </Pressable>
              )}
            />
          )}
          <View style={{ position: "absolute", bottom: 22, left: 22 }}>
            <Button title="＋ محادثة جديدة" onPress={() => setCreating(true)} />
          </View>
        </>
      )}
      {tab === "status" && <Statuses db={db} uid={uid} />}
      {tab === "profile" && profile && (
        <ProfileScreen
          db={db}
          initial={profile}
          email={session.user.email || ""}
          updated={refresh}
        />
      )}
      <Modal
        visible={creating}
        animationType="slide"
        onRequestClose={() => setCreating(false)}
      >
        <View style={[s.fill, { paddingTop: 35 }]}>
          <ScrollView
            contentContainerStyle={s.page}
            keyboardShouldPersistTaps="handled"
          >
            <Text style={s.title}>محادثة جديدة</Text>
            <View style={s.row}>
              <Button
                title="مجموعة"
                secondary={!group}
                onPress={() => setGroup(true)}
              />
              <Button
                title="شخص واحد"
                secondary={group}
                onPress={() => setGroup(false)}
              />
            </View>
            {group && (
              <Field
                placeholder="اسم المجموعة"
                value={groupTitle}
                onChangeText={setGroupTitle}
                maxLength={80}
              />
            )}
            <Field
              placeholder={
                group ? "أسماء المستخدمين، مفصولة بفاصلة" : "اسم مستخدم رفيقك"
              }
              autoCapitalize="none"
              value={handles}
              onChangeText={setHandles}
            />
            <Text style={s.subtitle}>
              خلي رفيقك يفتح «حسابي» ويعطيك اسم المستخدم. الإيميل ما بينعرض
              للآخرين.
            </Text>
            <Button
              title={busy ? "لحظة…" : "ابدأ الدردشة"}
              onPress={create}
              disabled={busy}
            />
            <Button
              secondary
              title="رجوع"
              onPress={() => setCreating(false)}
              disabled={busy}
            />
          </ScrollView>
        </View>
      </Modal>
    </View>
  );
}
function ProfileScreen({
  db,
  initial,
  email,
  updated,
}: {
  db: SupabaseClient;
  initial: Profile;
  email: string;
  updated: () => Promise<void>;
}) {
  const [name, setName] = useState(initial.display_name),
    [handle, setHandle] = useState(initial.handle),
    [about, setAbout] = useState(initial.about),
    [busy, setBusy] = useState(false),
    [blocked, setBlocked] = useState<{ blocked: string }[]>([]);
  const load = async () => {
    try {
      const r = check(await db.from("blocks").select("blocked"));
      setBlocked(r.data || []);
    } catch (e: any) {
      Alert.alert("خطأ", e.message);
    }
  };
  useEffect(() => {
    void load();
  }, []);
  return (
    <ScrollView
      contentContainerStyle={s.page}
      keyboardShouldPersistTaps="handled"
    >
      <View style={{ alignItems: "center", gap: 10 }}>
        <Avatar name={name} size={85} />
        <Text selectable style={[s.subtitle, { textAlign: "center" }]}>
          {email}
        </Text>
      </View>
      <Text style={s.text}>الاسم</Text>
      <Field value={name} onChangeText={setName} maxLength={60} />
      <Text style={s.text}>اسم المستخدم — شاركه مع رفقاتك</Text>
      <Field
        value={handle}
        onChangeText={(v) => setHandle(v.toLowerCase())}
        autoCapitalize="none"
        maxLength={24}
        style={{ textAlign: "left" }}
      />
      <Text style={s.subtitle}>3–24 حرف إنكليزي صغير أو رقم أو _</Text>
      <Field
        placeholder="نبذة عنك"
        value={about}
        onChangeText={setAbout}
        maxLength={160}
      />
      <Button
        disabled={busy}
        title={busy ? "عم نحفظ…" : "حفظ الحساب"}
        onPress={async () => {
          setBusy(true);
          try {
            if (!/^[a-z0-9_]{3,24}$/.test(handle))
              throw Error("تأكّد من صيغة اسم المستخدم");
            check(
              await db
                .from("profiles")
                .update({ display_name: name.trim(), handle, about })
                .eq("id", initial.id),
            );
            await updated();
            Alert.alert("تم", "حفظنا التعديلات");
          } catch (e: any) {
            Alert.alert(
              "تعذّر الحفظ",
              e.code === "23505" ? "اسم المستخدم مستخدم من شخص آخر" : e.message,
            );
          } finally {
            setBusy(false);
          }
        }}
      />
      {!!blocked.length && (
        <Text style={s.text}>المحظورون ({blocked.length})</Text>
      )}
      {blocked.map((x, i) => (
        <Button
          key={x.blocked}
          secondary
          title={`إلغاء حظر جهة اتصال ${i + 1}`}
          onPress={async () => {
            try {
              check(
                await db
                  .from("blocks")
                  .delete()
                  .eq("blocker", initial.id)
                  .eq("blocked", x.blocked),
              );
              await load();
            } catch (e: any) {
              Alert.alert("خطأ", e.message);
            }
          }}
        />
      ))}
      <View style={s.card}>
        <Text style={s.text}>وصلة · نسخة أولية 0.1</Text>
        <Text style={s.subtitle}>
          متوفر: دردشات، مجموعات، صور، فيديو وملفات قصيرة، رسائل صوتية وحالات
          نصية.{"\n"}غير متوفر بعد: المكالمات، إشعارات الخلفية، تشفير طرف لطرف،
          النسخ الاحتياطي.
        </Text>
      </View>
      <Button
        secondary
        title="تسجيل الخروج"
        onPress={() =>
          Alert.alert("تسجيل الخروج؟", "", [
            { text: "إلغاء" },
            {
              text: "خروج",
              onPress: async () => {
                try {
                  check(await db.auth.signOut());
                } catch (e: any) {
                  Alert.alert("خطأ", e.message);
                }
              },
            },
          ])
        }
      />
    </ScrollView>
  );
}
function Statuses({ db, uid }: { db: SupabaseClient; uid: string }) {
  const [stories, setStories] = useState<Story[]>([]),
    [body, setBody] = useState(""),
    [busy, setBusy] = useState(false),
    [error, setError] = useState("");
  const load = async () => {
    try {
      const r = check(
        await db
          .from("statuses")
          .select("*,profiles(*)")
          .gt("created_at", new Date(Date.now() - 86400000).toISOString())
          .order("created_at", { ascending: false })
          .limit(100),
      );
      setStories(r.data as unknown as Story[]);
      setError("");
    } catch (e: any) {
      setError(e.message);
    }
  };
  useEffect(() => {
    void load();
    const ch = db
      .channel("statuses")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "statuses" },
        () => void load(),
      )
      .subscribe();
    const timer = setInterval(() => void load(), 60000);
    return () => {
      clearInterval(timer);
      void db.removeChannel(ch);
    };
  }, []);
  return (
    <ScrollView
      contentContainerStyle={s.page}
      keyboardShouldPersistTaps="handled"
    >
      <Text style={s.title}>شو جديدك؟</Text>
      <Text style={s.subtitle}>
        حالتك بتظهر للي بتشاركهم محادثة، وبتختفي بعد 24 ساعة.
      </Text>
      <Field
        multiline
        placeholder="شارك لحظة من يومك…"
        value={body}
        onChangeText={setBody}
        maxLength={500}
      />
      <Button
        title="نشر الحالة"
        disabled={busy || !body.trim()}
        onPress={async () => {
          setBusy(true);
          try {
            check(
              await db
                .from("statuses")
                .insert({ user_id: uid, body: body.trim() }),
            );
            setBody("");
            await load();
          } catch (e: any) {
            setError(e.message);
          } finally {
            setBusy(false);
          }
        }}
      />
      {!!error && <Text style={s.error}>{error}</Text>}
      {stories.map((x) => (
        <View style={s.card} key={x.id}>
          <Text style={[s.text, { color: C.mint }]}>
            {x.profiles.display_name}
          </Text>
          <Text style={[s.text, { fontSize: 22, lineHeight: 33 }]}>
            {x.body}
          </Text>
          <Text style={s.subtitle}>
            {new Date(x.created_at).toLocaleTimeString("ar-LB", {
              hour: "2-digit",
              minute: "2-digit",
            })}
          </Text>
          {x.user_id === uid && (
            <Text
              style={s.link}
              onPress={async () => {
                try {
                  check(await db.from("statuses").delete().eq("id", x.id));
                  await load();
                } catch (e: any) {
                  setError(e.message);
                }
              }}
            >
              حذف حالتي
            </Text>
          )}
        </View>
      ))}
      {!stories.length && (
        <Text style={s.subtitle}>ما في حالات جديدة بعد.</Text>
      )}
    </ScrollView>
  );
}
