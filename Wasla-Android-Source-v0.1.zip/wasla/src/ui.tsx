import React from "react";
import {
  View,
  Text,
  TextInput,
  Pressable,
  StyleSheet,
  ActivityIndicator,
  TextInputProps,
} from "react-native";
export const C = {
  bg: "#071C22",
  panel: "#102C34",
  line: "#21404A",
  text: "#F2F8F6",
  muted: "#9AB4B9",
  mint: "#7EE7C0",
  dark: "#08362C",
  danger: "#FFA1A1",
};
export function Label({
  children,
  muted = false,
}: {
  children: React.ReactNode;
  muted?: boolean;
}) {
  return <Text style={[s.text, muted && { color: C.muted }]}>{children}</Text>;
}
export function Field(p: TextInputProps) {
  return (
    <TextInput
      placeholderTextColor={C.muted}
      {...p}
      style={[s.field, p.style]}
    />
  );
}
export function Button({
  title,
  onPress,
  secondary = false,
  disabled = false,
}: {
  title: string;
  onPress: () => void;
  secondary?: boolean;
  disabled?: boolean;
}) {
  return (
    <Pressable
      accessibilityRole="button"
      disabled={disabled}
      onPress={onPress}
      style={[
        s.button,
        secondary && {
          backgroundColor: C.panel,
          borderColor: C.line,
          borderWidth: 1,
        },
        disabled && { opacity: 0.45 },
      ]}
    >
      <Text
        style={{
          color: secondary ? C.text : C.dark,
          fontSize: 15,
          fontWeight: "700",
          textAlign: "center",
        }}
      >
        {title}
      </Text>
    </Pressable>
  );
}
export function Avatar({ name, size = 48 }: { name: string; size?: number }) {
  return (
    <View
      style={{
        width: size,
        height: size,
        borderRadius: size / 2,
        backgroundColor: "#254E51",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      <Text style={{ fontSize: size * 0.4, color: C.mint, fontWeight: "800" }}>
        {name.trim().slice(0, 1).toUpperCase() || "و"}
      </Text>
    </View>
  );
}
export function Busy() {
  return (
    <View style={s.center}>
      <ActivityIndicator color={C.mint} />
    </View>
  );
}
export const s = StyleSheet.create({
  fill: { flex: 1, backgroundColor: C.bg },
  center: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 24,
  },
  page: { padding: 24, gap: 14, paddingBottom: 48 },
  text: { color: C.text, fontSize: 15, lineHeight: 24, textAlign: "right" },
  field: {
    borderWidth: 1,
    borderColor: C.line,
    borderRadius: 16,
    padding: 14,
    color: C.text,
    backgroundColor: C.panel,
    fontSize: 16,
    textAlign: "right",
  },
  button: {
    paddingVertical: 14,
    paddingHorizontal: 17,
    borderRadius: 16,
    backgroundColor: C.mint,
  },
  title: { color: C.text, fontWeight: "800", fontSize: 30, textAlign: "right" },
  subtitle: {
    color: C.muted,
    fontSize: 14,
    lineHeight: 23,
    textAlign: "right",
  },
  row: { flexDirection: "row", alignItems: "center", gap: 12 },
  header: {
    paddingHorizontal: 22,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderColor: C.line,
  },
  card: { padding: 18, borderRadius: 20, backgroundColor: C.panel, gap: 10 },
  error: { color: C.danger, textAlign: "right", padding: 14, lineHeight: 23 },
  link: {
    color: C.mint,
    fontWeight: "700",
    fontSize: 15,
    textAlign: "center",
    padding: 12,
  },
  tag: { color: C.mint, fontSize: 12, fontWeight: "700", letterSpacing: 1.5 },
});
