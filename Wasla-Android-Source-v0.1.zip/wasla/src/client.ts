import { PROJECT } from "./project";
import "react-native-url-polyfill/auto";
import { createClient, SupabaseClient } from "@supabase/supabase-js";
import AsyncStorage from "@react-native-async-storage/async-storage";
import * as SecureStore from "expo-secure-store";
import { Platform } from "react-native";
import { File } from "expo-file-system";
import * as Crypto from "expo-crypto";
export type Config = { url: string; key: string };
export type Profile = {
  id: string;
  handle: string;
  display_name: string;
  about: string;
};
export type Member = { user_id: string; last_read: string; profiles: Profile };
export type Room = {
  id: string;
  title: string;
  is_group: boolean;
  owner_id: string;
  updated_at: string;
  members: Member[];
};
export type Message = {
  id: string;
  room_id: string;
  sender_id: string;
  body: string;
  kind: "text" | "image" | "video" | "audio" | "file";
  file_path: string | null;
  file_name: string | null;
  reply_to: string | null;
  created_at: string;
  edited_at: string | null;
  deleted: boolean;
  profiles: Profile;
  reactions: { emoji: string; user_id: string }[];
};
export type Story = {
  id: string;
  body: string;
  created_at: string;
  user_id: string;
  profiles: Profile;
};
// Store session in platform-encrypted storage, chunked for Android key size limits.
const secure = {
  async getItem(k: string) {
    if (Platform.OS === "web") return AsyncStorage.getItem(k);
    const n = Number(await SecureStore.getItemAsync(k + ".count"));
    if (!n) return null;
    const parts = await Promise.all(
      Array.from({ length: n }, (_, i) =>
        SecureStore.getItemAsync(k + "." + i),
      ),
    );
    return parts.some((x) => x === null) ? null : parts.join("");
  },
  async setItem(k: string, v: string) {
    if (Platform.OS === "web") return AsyncStorage.setItem(k, v);
    const old = Number(await SecureStore.getItemAsync(k + ".count"));
    const n = Math.ceil(v.length / 1500);
    for (let i = 0; i < n; i++)
      await SecureStore.setItemAsync(
        k + "." + i,
        v.slice(i * 1500, (i + 1) * 1500),
      );
    await SecureStore.setItemAsync(k + ".count", String(n));
    for (let i = n; i < old; i++)
      await SecureStore.deleteItemAsync(k + "." + i);
  },
  async removeItem(k: string) {
    if (Platform.OS === "web") return AsyncStorage.removeItem(k);
    const n = Number(await SecureStore.getItemAsync(k + ".count"));
    await SecureStore.deleteItemAsync(k + ".count");
    for (let i = 0; i < n; i++) await SecureStore.deleteItemAsync(k + "." + i);
  },
};
export async function loadConfig(): Promise<Config | null> {
  const raw = await AsyncStorage.getItem("wasla.config");
  if (raw) return JSON.parse(raw);
  const url = process.env.EXPO_PUBLIC_SUPABASE_URL || PROJECT.url,
    key = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY || PROJECT.key;
  return url && key ? { url, key } : null;
}
export async function saveConfig(c: Config) {
  const url = new URL(c.url);
  if (url.protocol !== "https:" || !url.hostname.endsWith(".supabase.co"))
    throw Error("أدخل رابط مشروع Supabase الصحيح");
  if (c.key.startsWith("sb_secret_"))
    throw Error("استخدم المفتاح العام Publishable فقط");
  if (!c.key.startsWith("sb_publishable_")) {
    try {
      const payload = JSON.parse(atob(c.key.split(".")[1]));
      if (payload.role !== "anon") throw Error();
    } catch {
      throw Error("استخدم Publishable أو anon key فقط، وليس service_role");
    }
  }
  await AsyncStorage.setItem("wasla.config", JSON.stringify(c));
}
export function makeClient(c: Config) {
  return createClient(c.url, c.key, {
    auth: {
      storage: secure,
      autoRefreshToken: true,
      persistSession: true,
      detectSessionInUrl: false,
    },
  });
}
export function check<T extends { error: any }>(r: T): T {
  if (r.error) throw r.error;
  return r;
}
export async function rooms(db: SupabaseClient): Promise<Room[]> {
  return check(
    await db
      .from("rooms")
      .select("*,members(user_id,last_read,profiles(*))")
      .order("updated_at", { ascending: false }),
  ).data as unknown as Room[];
}
export async function messages(
  db: SupabaseClient,
  r: string,
  before?: string,
): Promise<Message[]> {
  let q = db
    .from("messages")
    .select("*,profiles!messages_sender_id_fkey(*),reactions(emoji,user_id)")
    .eq("room_id", r)
    .order("created_at", { ascending: false })
    .order("id", { ascending: false })
    .limit(60);
  if (before) q = q.lt("created_at", before);
  return check(await q).data as unknown as Message[];
}
export function roomTitle(r: Room, uid: string) {
  return r.is_group
    ? r.title
    : r.members.find((m) => m.user_id !== uid)?.profiles?.display_name ||
        "محادثة";
}
export async function upload(
  db: SupabaseClient,
  room: string,
  uid: string,
  uri: string,
  name: string,
  type: string,
) {
  const f = new File(uri);
  if (f.size > 6 * 1024 * 1024)
    throw Error("الحد الأقصى للملف 6 MB للحفاظ على الخطة المجانية");
  const ext =
    name
      .split(".")
      .pop()
      ?.replace(/[^a-zA-Z0-9]/g, "")
      .slice(0, 8) || "bin";
  const path = `${room}/${uid}/${Crypto.randomUUID()}.${ext}`;
  check(
    await db.storage
      .from("chat-media")
      .upload(path, await f.arrayBuffer(), {
        contentType: type,
        upsert: false,
      }),
  );
  return path;
}
export async function mediaUrl(db: SupabaseClient, path: string) {
  const r = check(
    await db.storage.from("chat-media").createSignedUrl(path, 300),
  );
  if (!r.data) throw Error("تعذّر فتح المرفق");
  return r.data.signedUrl;
}
