// Public client configuration supplied by the project owner.
// This publishable key is intentionally bundled; access is enforced by RLS.
export const PROJECT = {
  url: 'https://azxxqpuylvhhyzckrzkv.supabase.co',
  key: 'sb_publishable_h9a7WT8x9PQa7NCzjySB0g_iiDXUEZM',
};
