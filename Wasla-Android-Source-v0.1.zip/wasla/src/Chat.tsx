import React, { useEffect, useRef, useState } from "react";
import {
  View,
  Text,
  FlatList,
  Pressable,
  Image,
  Modal,
  ScrollView,
  Alert,
  KeyboardAvoidingView,
  Platform,
  Linking,
  AppState,
} from "react-native";
import { SupabaseClient } from "@supabase/supabase-js";
import * as ImagePicker from "expo-image-picker";
import * as DocumentPicker from "expo-document-picker";
import * as Crypto from "expo-crypto";
import {
  AudioModule,
  RecordingPresets,
  setAudioModeAsync,
  useAudioRecorder,
  useAudioRecorderState,
  useAudioPlayer,
  useAudioPlayerStatus,
} from "expo-audio";
import { VideoView, useVideoPlayer } from "expo-video";
import {
  Room,
  Message,
  check,
  messages,
  roomTitle,
  upload,
  mediaUrl,
} from "./client";
import { Avatar, Button, Field, Busy, C, s } from "./ui";
export default function Chat({
  db,
  room,
  uid,
  back,
}: {
  db: SupabaseClient;
  room: Room;
  uid: string;
  back: () => void;
}) {
  const [items, setItems] = useState<Message[]>([]),
    [text, setText] = useState(""),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false),
    [loading, setLoading] = useState(true),
    [reply, setReply] = useState<Message | null>(null),
    [editing, setEditing] = useState<Message | null>(null),
    [selected, setSelected] = useState<Message | null>(null),
    [detail, setDetail] = useState(false),
    [memberHandle, setMemberHandle] = useState(""),
    [query, setQuery] = useState(""),
    [search, setSearch] = useState(false),
    [more, setMore] = useState(true),
    [paging, setPaging] = useState(false);
  const [draft, setDraft] = useState<{
    path: string;
    name: string;
    kind: Message["kind"];
  } | null>(null);
  const [voiceDraft, setVoiceDraft] = useState<string | null>(null);
  const recorder = useAudioRecorder(RecordingPresets.HIGH_QUALITY),
    record = useAudioRecorderState(recorder);
  const count = useRef(60),
    pending = useRef<{ fingerprint: string; id: string } | null>(null),
    loadingOlder = useRef(false),
    alive = useRef(true),
    latestRequest = useRef(0);
  async function load(mark = false) {
    const request = ++latestRequest.current;
    try {
      const r = check(
        await db
          .from("messages")
          .select(
            "*,profiles!messages_sender_id_fkey(*),reactions(emoji,user_id)",
          )
          .eq("room_id", room.id)
          .order("created_at", { ascending: false })
          .order("id", { ascending: false })
          .limit(count.current),
      );
      if (!alive.current || request !== latestRequest.current) return;
      setItems(r.data as unknown as Message[]);
      setMore((r.data?.length || 0) >= count.current);
      setError("");
      if (mark && AppState.currentState === "active")
        check(await db.rpc("mark_read", { r: room.id }));
    } catch (e: any) {
      if (alive.current) setError(e.message);
    } finally {
      if (alive.current) setLoading(false);
    }
  }
  useEffect(() => {
    alive.current = true;
    void load(true);
    let timer: ReturnType<typeof setTimeout>;
    const changed = (mark = false) => {
      clearTimeout(timer);
      timer = setTimeout(() => void load(mark), 180);
    };
    const channel = db
      .channel("room-" + room.id)
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "messages",
          filter: `room_id=eq.${room.id}`,
        },
        () => changed(true),
      )
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "reactions" },
        () => changed(),
      )
      .subscribe((status) => {
        if (status === "SUBSCRIBED") changed(true);
        if (status === "CHANNEL_ERROR" || status === "TIMED_OUT")
          setError("انقطع الاتصال المباشر. جرّب تحديث الرسائل.");
      });
    const state = AppState.addEventListener("change", (x) => {
      if (x === "active") changed(true);
    });
    return () => {
      alive.current = false;
      clearTimeout(timer);
      state.remove();
      void db.removeChannel(channel);
      void recorder.stop().catch(() => {});
    };
  }, [room.id]);
  useEffect(() => {
    if (record.isRecording && record.durationMillis >= 60000) {
      void recorder
        .stop()
        .then(async () => {
          await setAudioModeAsync({
            allowsRecording: false,
            playsInSilentMode: true,
          });
          setVoiceDraft(recorder.uri);
          setError("وصل التسجيل لدقيقة. اضغط «إرسال التسجيل».");
        })
        .catch((e: any) => setError(e.message));
    }
  }, [record.durationMillis]);
  async function send(
    kind: Message["kind"] = "text",
    path?: string,
    name?: string,
  ) {
    const body = text.trim();
    if (kind === "text" && !body) return;
    setBusy(true);
    setError("");
    try {
      if (editing) {
        check(await db.rpc("edit_message", { m: editing.id, b: body }));
        setEditing(null);
      } else {
        const fingerprint = JSON.stringify([body, kind, path, reply?.id]);
        if (pending.current?.fingerprint !== fingerprint)
          pending.current = { fingerprint, id: Crypto.randomUUID() };
        check(
          await db.rpc("send_message", {
            r: room.id,
            b: body,
            k: kind,
            path: path || null,
            filename: name || null,
            reply: reply?.id || null,
            message_id: pending.current.id,
          }),
        );
        pending.current = null;
      }
      setText("");
      setReply(null);
      setDraft(null);
      setVoiceDraft(null);
      await load();
    } catch (e: any) {
      setError("لم نتأكّد من الإرسال: " + e.message);
    } finally {
      setBusy(false);
    }
  }
  async function attachment(
    uri: string,
    name: string,
    mime: string,
    kind: Message["kind"],
  ) {
    setBusy(true);
    try {
      const path = await upload(db, room.id, uid, uri, name, mime);
      setDraft({ path, name, kind });
      await send(kind, path, name);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  }
  async function pick(image: boolean) {
    try {
      if (image) {
        const r = await ImagePicker.launchImageLibraryAsync({
          mediaTypes: ["images", "videos"],
          quality: 0.7,
          videoMaxDuration: 30,
        });
        if (!r.canceled) {
          const a = r.assets[0];
          await attachment(
            a.uri,
            a.fileName || (a.type === "video" ? "video.mp4" : "image.jpg"),
            a.mimeType || (a.type === "video" ? "video/mp4" : "image/jpeg"),
            a.type === "video" ? "video" : "image",
          );
        }
      } else {
        const r = await DocumentPicker.getDocumentAsync({
          copyToCacheDirectory: true,
        });
        if (!r.canceled) {
          const a = r.assets[0];
          await attachment(
            a.uri,
            a.name,
            a.mimeType || "application/octet-stream",
            "file",
          );
        }
      }
    } catch (e: any) {
      setError(e.message);
    }
  }
  async function voice() {
    try {
      if (record.isRecording) {
        await recorder.stop();
        await setAudioModeAsync({
          allowsRecording: false,
          playsInSilentMode: true,
        });
        if (recorder.uri) {
          setVoiceDraft(recorder.uri);
          await attachment(recorder.uri, "voice.m4a", "audio/mp4", "audio");
        }
      } else {
        const r = await AudioModule.requestRecordingPermissionsAsync();
        if (!r.granted)
          throw Error("اسمح باستعمال الميكروفون من إعدادات التطبيق");
        await setAudioModeAsync({
          allowsRecording: true,
          playsInSilentMode: true,
        });
        await recorder.prepareToRecordAsync();
        recorder.record();
      }
    } catch (e: any) {
      setError(e.message);
    }
  }
  async function react(emoji: string) {
    if (!selected) return;
    try {
      check(
        await db
          .from("reactions")
          .upsert({ message_id: selected.id, user_id: uid, emoji }),
      );
      setSelected(null);
      await load();
    } catch (e: any) {
      setError(e.message);
      setSelected(null);
    }
  }
  const others = room.members.filter((m) => m.user_id !== uid);
  const readBy = (m: Message) =>
    others.filter((x) => Date.parse(x.last_read) >= Date.parse(m.created_at))
      .length;
  return (
    <KeyboardAvoidingView
      style={s.fill}
      behavior={Platform.OS === "ios" ? "padding" : undefined}
    >
      <View style={[s.header, s.row]}>
        <Pressable onPress={back} accessibilityLabel="رجوع">
          <Text style={{ color: C.mint, fontSize: 28 }}>‹</Text>
        </Pressable>
        <Pressable onPress={() => setSearch(!search)} accessibilityLabel="بحث">
          <Text style={{ color: C.mint, fontSize: 22 }}>⌕</Text>
        </Pressable>
        <Pressable onPress={() => setDetail(true)} style={{ flex: 1 }}>
          <Text
            numberOfLines={1}
            style={[s.text, { fontWeight: "800", fontSize: 18 }]}
          >
            {roomTitle(room, uid)}
          </Text>
          <Text style={[s.subtitle, { fontSize: 12 }]}>
            {room.is_group
              ? `${room.members.length} أعضاء · معلومات المجموعة`
              : "اضغط لمعلومات المحادثة"}
          </Text>
        </Pressable>
        <Avatar name={roomTitle(room, uid)} size={42} />
      </View>
      {search && (
        <View style={{ padding: 10 }}>
          <Field
            placeholder="بحث في الرسائل المحمّلة…"
            value={query}
            onChangeText={setQuery}
          />
        </View>
      )}
      {!!error && (
        <Pressable onPress={() => void load()}>
          <Text style={s.error}>{error} · اضغط للتحديث</Text>
        </Pressable>
      )}
      {loading ? (
        <Busy />
      ) : (
        <FlatList
          inverted
          data={items.filter(
            (m) => !query || m.body.toLowerCase().includes(query.toLowerCase()),
          )}
          keyExtractor={(m) => m.id}
          contentContainerStyle={{ padding: 16, gap: 10 }}
          keyboardShouldPersistTaps="handled"
          ListEmptyComponent={
            <View style={{ transform: [{ scaleY: -1 }], padding: 40 }}>
              <Text style={[s.subtitle, { textAlign: "center" }]}>
                بلّش الحديث بـ «مرحبا» 👋
              </Text>
            </View>
          }
          ListFooterComponent={
            more ? (
              <Button
                secondary
                title={paging ? "عم نحمّل…" : "رسائل أقدم"}
                disabled={paging}
                onPress={async () => {
                  if (loadingOlder.current) return;
                  loadingOlder.current = true;
                  setPaging(true);
                  count.current += 60;
                  await load();
                  setPaging(false);
                  loadingOlder.current = false;
                }}
              />
            ) : null
          }
          renderItem={({ item: m }) => (
            <Pressable
              onLongPress={() => !m.deleted && setSelected(m)}
              delayLongPress={300}
              style={{
                maxWidth: "87%",
                alignSelf: m.sender_id === uid ? "flex-end" : "flex-start",
                backgroundColor: m.sender_id === uid ? "#174D43" : C.panel,
                padding: 13,
                borderRadius: 18,
                borderBottomRightRadius: m.sender_id === uid ? 4 : 18,
                borderBottomLeftRadius: m.sender_id === uid ? 18 : 4,
                gap: 5,
              }}
            >
              {room.is_group && m.sender_id !== uid && (
                <Text
                  style={{ color: C.mint, fontSize: 12, fontWeight: "700" }}
                >
                  {m.profiles?.display_name}
                </Text>
              )}
              {!!m.reply_to && !m.deleted && (
                <View
                  style={{
                    padding: 8,
                    borderRightWidth: 3,
                    borderColor: C.mint,
                    backgroundColor: "#ffffff09",
                  }}
                >
                  <Text numberOfLines={2} style={s.subtitle}>
                    ↩{" "}
                    {items.find((x) => x.id === m.reply_to)?.body ||
                      "ردّ على رسالة"}
                  </Text>
                </View>
              )}
              {m.deleted ? (
                <Text style={s.subtitle}>تم حذف الرسالة</Text>
              ) : (
                <>
                  {m.file_path && <Attachment db={db} message={m} />}{" "}
                  {!!m.body && (
                    <Text selectable style={s.text}>
                      {m.body}
                    </Text>
                  )}
                </>
              )}
              {!!m.reactions?.length && !m.deleted && (
                <Text style={{ color: C.text }}>
                  {m.reactions.map((x) => x.emoji).join(" ")}
                </Text>
              )}
              <Text
                style={{
                  fontSize: 10,
                  color:
                    m.sender_id === uid && readBy(m) > 0 ? "#85DDFB" : C.muted,
                  textAlign: "right",
                }}
              >
                {m.edited_at && !m.deleted ? "معدّلة · " : ""}
                {new Date(m.created_at).toLocaleTimeString("ar-LB", {
                  hour: "2-digit",
                  minute: "2-digit",
                })}
                {m.sender_id === uid
                  ? readBy(m) > 0
                    ? ` · قرأها ${readBy(m)}`
                    : " · أُرسلت"
                  : ""}
              </Text>
            </Pressable>
          )}
        />
      )}
      {(reply || editing) && (
        <View
          style={[
            s.row,
            {
              backgroundColor: C.panel,
              paddingHorizontal: 14,
              paddingVertical: 8,
            },
          ]}
        >
          <Pressable
            onPress={() => {
              setReply(null);
              setEditing(null);
              setText("");
            }}
          >
            <Text style={s.link}>✕</Text>
          </Pressable>
          <Text numberOfLines={2} style={[s.subtitle, { flex: 1 }]}>
            {editing ? "تعديل: " : "ردّ: "}
            {(editing || reply)?.body || "مرفق"}
          </Text>
        </View>
      )}
      {record.isRecording && (
        <Text style={[s.text, { color: C.danger, padding: 10 }]}>
          ● عم نسجّل… {Math.floor(record.durationMillis / 1000)} ثانية
        </Text>
      )}
      {!record.isRecording && voiceDraft && !draft && (
        <Button
          title="إرسال التسجيل"
          disabled={busy}
          onPress={() =>
            void attachment(voiceDraft, "voice.m4a", "audio/mp4", "audio")
          }
        />
      )}
      {draft && (
        <View style={[s.row, { padding: 10 }]}>
          <Button
            title="إعادة إرسال المرفق"
            disabled={busy}
            onPress={() => void send(draft.kind, draft.path, draft.name)}
          />
          <Text style={[s.subtitle, { flex: 1 }]}>{draft.name}</Text>
          <Button
            secondary
            title="إخفاء"
            disabled={busy}
            onPress={() => {
              setDraft(null);
              setVoiceDraft(null);
              pending.current = null;
            }}
          />
        </View>
      )}
      <View
        style={[s.row, { padding: 10, borderTopWidth: 1, borderColor: C.line }]}
      >
        <Button
          title={
            busy
              ? "…"
              : editing
                ? "حفظ التعديل"
                : record.isRecording
                  ? "إرسال الصوت"
                  : text.trim()
                    ? "إرسال"
                    : "صوت"
          }
          disabled={busy || !!draft || (!!editing && !text.trim())}
          onPress={() => {
            if (editing) void send();
            else if (record.isRecording || !text.trim()) void voice();
            else void send();
          }}
        />
        <Field
          placeholder="اكتب رسالة…"
          value={text}
          onChangeText={setText}
          multiline
          maxLength={4000}
          editable={!busy && !record.isRecording}
          style={{ flex: 1, maxHeight: 110 }}
        />
        <Pressable
          disabled={busy || record.isRecording || !!editing || !!draft}
          onPress={() =>
            Alert.alert("إرفاق", "", [
              { text: "صور أو فيديو", onPress: () => void pick(true) },
              { text: "ملف", onPress: () => void pick(false) },
              { text: "إلغاء", style: "cancel" },
            ])
          }
        >
          <Text style={{ fontSize: 28, color: C.mint, padding: 5 }}>＋</Text>
        </Pressable>
      </View>
      <Modal
        transparent
        visible={!!selected}
        animationType="fade"
        onRequestClose={() => setSelected(null)}
      >
        <View
          style={{
            flex: 1,
            backgroundColor: "#0009",
            justifyContent: "flex-end",
          }}
        >
          <View
            style={[
              s.page,
              {
                backgroundColor: C.panel,
                borderTopLeftRadius: 24,
                borderTopRightRadius: 24,
              },
            ]}
          >
            <View style={[s.row, { justifyContent: "space-around" }]}>
              {["❤️", "👍", "😂", "😮", "😢"].map((e) => (
                <Pressable key={e} onPress={() => void react(e)}>
                  <Text style={{ fontSize: 30, padding: 7 }}>{e}</Text>
                </Pressable>
              ))}
            </View>
            <Button
              title="ردّ"
              onPress={() => {
                setReply(selected);
                setEditing(null);
                setSelected(null);
              }}
            />
            {selected?.sender_id === uid && (
              <>
                <Button
                  secondary
                  title="تعديل النص"
                  onPress={() => {
                    setEditing(selected);
                    setText(selected.body);
                    setReply(null);
                    setSelected(null);
                  }}
                />
                <Button
                  secondary
                  title="حذف عند الجميع"
                  onPress={() => {
                    const m = selected;
                    setSelected(null);
                    Alert.alert("حذف الرسالة؟", "ما فيك ترجّعها بعد الحذف.", [
                      { text: "إلغاء" },
                      {
                        text: "حذف",
                        style: "destructive",
                        onPress: async () => {
                          try {
                            check(
                              await db.rpc("edit_message", {
                                m: m.id,
                                b: null,
                              }),
                            );
                            if (m.file_path)
                              check(
                                await db.storage
                                  .from("chat-media")
                                  .remove([m.file_path]),
                              );
                            await load();
                          } catch (e: any) {
                            setError(e.message);
                          }
                        },
                      },
                    ]);
                  }}
                />
              </>
            )}
            <Button secondary title="إغلاق" onPress={() => setSelected(null)} />
          </View>
        </View>
      </Modal>
      <Modal
        visible={detail}
        animationType="slide"
        onRequestClose={() => setDetail(false)}
      >
        <View style={[s.fill, { paddingTop: 35 }]}>
          <ScrollView contentContainerStyle={s.page}>
            <Text style={s.title}>{roomTitle(room, uid)}</Text>
            <Text style={s.subtitle}>أعضاء المحادثة</Text>
            {room.members.map((m) => (
              <View key={m.user_id} style={[s.card, s.row]}>
                <Avatar name={m.profiles?.display_name || "؟"} />
                <View style={{ flex: 1 }}>
                  <Text style={s.text}>{m.profiles?.display_name}</Text>
                  <Text selectable style={s.subtitle}>
                    @{m.profiles?.handle}
                    {room.owner_id === m.user_id ? " · مسؤول" : ""}
                  </Text>
                </View>
                {room.is_group &&
                  room.owner_id === uid &&
                  m.user_id !== uid && (
                    <Pressable
                      onPress={() =>
                        Alert.alert(
                          "إزالة العضو؟",
                          "سيفقد الوصول لمحادثات المجموعة.",
                          [
                            { text: "إلغاء" },
                            {
                              text: "إزالة",
                              onPress: async () => {
                                try {
                                  check(
                                    await db.rpc("manage_group", {
                                      r: room.id,
                                      member_handle: m.profiles.handle,
                                      remove_member: true,
                                    }),
                                  );
                                  setDetail(false);
                                } catch (e: any) {
                                  Alert.alert("خطأ", e.message);
                                }
                              },
                            },
                          ],
                        )
                      }
                    >
                      <Text style={{ color: C.danger }}>إزالة</Text>
                    </Pressable>
                  )}
              </View>
            ))}
            {room.is_group && room.owner_id === uid && (
              <>
                <Field
                  placeholder="اسم مستخدم لإضافته"
                  value={memberHandle}
                  onChangeText={setMemberHandle}
                  autoCapitalize="none"
                />
                <Button
                  title="إضافة عضو"
                  onPress={async () => {
                    try {
                      check(
                        await db.rpc("manage_group", {
                          r: room.id,
                          member_handle: memberHandle
                            .trim()
                            .replace(/^@/, "")
                            .toLowerCase(),
                        }),
                      );
                      setMemberHandle("");
                      setDetail(false);
                    } catch (e: any) {
                      Alert.alert("خطأ", e.message);
                    }
                  }}
                />
              </>
            )}
            {!room.is_group && others[0] && (
              <Button
                secondary
                title="حظر هذا المستخدم"
                onPress={() =>
                  Alert.alert(
                    "حظر المستخدم؟",
                    "يتوقف إرسال الرسائل بينكما. يمكنك إلغاء الحظر من حسابي.",
                    [
                      { text: "إلغاء" },
                      {
                        text: "حظر",
                        onPress: async () => {
                          try {
                            check(
                              await db
                                .from("blocks")
                                .upsert(
                                  { blocker: uid, blocked: others[0].user_id },
                                  { ignoreDuplicates: true },
                                ),
                            );
                            setDetail(false);
                            back();
                          } catch (e: any) {
                            Alert.alert("خطأ", e.message);
                          }
                        },
                      },
                    ],
                  )
                }
              />
            )}
            <Button title="رجوع للمحادثة" onPress={() => setDetail(false)} />
          </ScrollView>
        </View>
      </Modal>
    </KeyboardAvoidingView>
  );
}
function Attachment({
  db,
  message: m,
}: {
  db: SupabaseClient;
  message: Message;
}) {
  const [url, setUrl] = useState(""),
    [error, setError] = useState(""),
    [expanded, setExpanded] = useState(false);
  useEffect(() => {
    let alive = true;
    const load = () =>
      mediaUrl(db, m.file_path!)
        .then((u) => {
          if (alive) {
            setUrl(u);
            setError("");
          }
        })
        .catch((e) => {
          if (alive) setError(e.message);
        });
    void load();
    const timer = setInterval(() => void load(), 240000);
    return () => {
      alive = false;
      clearInterval(timer);
    };
  }, [m.file_path]);
  if (error) return <Text style={s.error}>تعذّر تحميل المرفق</Text>;
  if (!url) return <Text style={s.subtitle}>عم نحمّل المرفق…</Text>;
  if (m.kind === "audio") return <Voice url={url} />;
  return (
    <View>
      {m.kind === "image" ? (
        <Pressable onPress={() => setExpanded(true)}>
          <Image
            source={{ uri: url }}
            style={{ width: 235, height: 210, borderRadius: 12 }}
            resizeMode="cover"
          />
        </Pressable>
      ) : (
        <Button
          secondary
          title={
            m.kind === "video"
              ? "▶ عرض الفيديو"
              : `↗ ${m.file_name || "فتح الملف"}`
          }
          onPress={() => {
            if (m.kind === "video") setExpanded(true);
            else
              void Linking.openURL(url).catch(() =>
                Alert.alert("تعذّر فتح الملف"),
              );
          }}
        />
      )}
      <Modal visible={expanded} onRequestClose={() => setExpanded(false)}>
        <View style={s.fill}>
          {expanded &&
            (m.kind === "video" ? (
              <Movie url={url} />
            ) : (
              <Image
                source={{ uri: url }}
                style={{ flex: 1 }}
                resizeMode="contain"
              />
            ))}
          <View style={{ padding: 22 }}>
            <Button title="رجوع" onPress={() => setExpanded(false)} />
          </View>
        </View>
      </Modal>
    </View>
  );
}
function Voice({ url }: { url: string }) {
  const player = useAudioPlayer(url),
    status = useAudioPlayerStatus(player);
  return (
    <Pressable
      onPress={() => {
        if (status.playing) player.pause();
        else {
          if (status.didJustFinish) void player.seekTo(0);
          player.play();
        }
      }}
      style={[s.row, { minWidth: 190, padding: 10 }]}
    >
      <Text style={{ color: C.mint, fontSize: 24 }}>
        {status.playing ? "Ⅱ" : "▶"}
      </Text>
      <View style={{ flex: 1, height: 3, backgroundColor: C.line }}>
        <View
          style={{
            width: `${Math.min(100, (status.currentTime / (status.duration || 1)) * 100)}%`,
            height: 3,
            backgroundColor: C.mint,
          }}
        />
      </View>
      <Text style={s.subtitle}>{Math.floor(status.currentTime)}s</Text>
    </Pressable>
  );
}
function Movie({ url }: { url: string }) {
  const player = useVideoPlayer(url, (p) => p.play());
  return (
    <VideoView
      player={player}
      style={{ flex: 1 }}
      nativeControls
      contentFit="contain"
    />
  );
}
