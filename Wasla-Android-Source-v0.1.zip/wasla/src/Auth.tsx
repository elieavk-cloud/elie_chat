import React, { useState } from "react";
import {
  ScrollView,
  Text,
  View,
  KeyboardAvoidingView,
  Platform,
} from "react-native";
import { SupabaseClient } from "@supabase/supabase-js";
import { Button, Field, s, C } from "./ui";
import { check } from "./client";
export default function Auth({
  db,
  onReset,
}: {
  db: SupabaseClient;
  onReset: () => void;
}) {
  const [mode, setMode] = useState<
    "login" | "signup" | "verify" | "recover" | "reset"
  >("login");
  const [email, setEmail] = useState(""),
    [password, setPassword] = useState(""),
    [name, setName] = useState(""),
    [code, setCode] = useState(""),
    [busy, setBusy] = useState(false),
    [error, setError] = useState(""),
    [info, setInfo] = useState("");
  async function submit() {
    setError("");
    setInfo("");
    setBusy(true);
    try {
      const e = email.trim().toLowerCase();
      if (!/^\S+@\S+\.\S+$/.test(e)) throw Error("أدخل إيميل صحيح");
      if (mode === "login")
        check(await db.auth.signInWithPassword({ email: e, password }));
      if (mode === "signup") {
        if (password.length < 8) throw Error("كلمة المرور 8 أحرف على الأقل");
        if (!name.trim()) throw Error("أدخل اسمك");
        const r = check(
          await db.auth.signUp({
            email: e,
            password,
            options: { data: { display_name: name.trim() } },
          }),
        );
        if (!r.data.session) {
          setMode("verify");
          setInfo(
            "أدخل كود التأكيد من الإيميل. إذا وصلك رابط، افتحه ثم ارجع وسجّل دخولك.",
          );
        }
      }
      if (mode === "verify")
        check(
          await db.auth.verifyOtp({
            email: e,
            token: code.trim(),
            type: "signup",
          }),
        );
      if (mode === "recover") {
        check(await db.auth.resetPasswordForEmail(e));
        setMode("reset");
        setInfo("إذا كان الحساب موجوداً، سيصلك كود الاستعادة.");
      }
      if (mode === "reset") {
        if (password.length < 8) throw Error("كلمة المرور 8 أحرف على الأقل");
        check(
          await db.auth.verifyOtp({
            email: e,
            token: code.trim(),
            type: "recovery",
          }),
        );
        check(await db.auth.updateUser({ password }));
        setInfo("تغيّرت كلمة المرور.");
      }
    } catch (e: any) {
      setError(e.message || "تعذّر الاتصال");
    } finally {
      setBusy(false);
    }
  }
  const title = {
    login: "أهلاً في وصلة",
    signup: "خلّينا نتعرّف عليك",
    verify: "تأكّد من إيميلك",
    recover: "استرجع حسابك",
    reset: "كلمة مرور جديدة",
  }[mode];
  return (
    <KeyboardAvoidingView
      style={s.fill}
      behavior={Platform.OS === "ios" ? "padding" : undefined}
    >
      <ScrollView
        contentContainerStyle={[s.page, { paddingTop: 55 }]}
        keyboardShouldPersistTaps="handled"
      >
        <View
          style={{
            width: 78,
            height: 78,
            borderRadius: 26,
            backgroundColor: C.mint,
            justifyContent: "center",
            alignItems: "center",
            alignSelf: "flex-end",
            marginBottom: 20,
          }}
        >
          <Text style={{ fontSize: 43, color: C.dark, fontWeight: "900" }}>
            و
          </Text>
        </View>
        <Text style={s.tag}>WASLA · وصلة</Text>
        <Text style={s.title}>{title}</Text>
        <Text style={s.subtitle}>
          قريب من ناسك، وين ما كنت.{"\n"}دخول بالإيميل، بلا رقم تلفون.
        </Text>
        {mode === "signup" && (
          <Field
            placeholder="اسمك"
            value={name}
            onChangeText={setName}
            maxLength={60}
          />
        )}
        <Field
          placeholder="الإيميل"
          value={email}
          onChangeText={setEmail}
          keyboardType="email-address"
          autoCapitalize="none"
          autoComplete="email"
          style={{ textAlign: "left" }}
        />
        {["login", "signup", "reset"].includes(mode) && (
          <Field
            placeholder="كلمة المرور"
            value={password}
            onChangeText={setPassword}
            secureTextEntry
            autoCapitalize="none"
          />
        )}
        {["verify", "reset"].includes(mode) && (
          <Field
            placeholder="كود التأكيد"
            value={code}
            onChangeText={setCode}
            keyboardType="number-pad"
          />
        )}
        {!!error && <Text style={s.error}>{error}</Text>}
        {!!info && <Text style={s.subtitle}>{info}</Text>}
        <Button
          title={
            busy
              ? "لحظة…"
              : mode === "login"
                ? "دخول"
                : mode === "signup"
                  ? "إنشاء حساب"
                  : mode === "recover"
                    ? "إرسال كود الاستعادة"
                    : "تأكيد"
          }
          onPress={submit}
          disabled={busy}
        />
        <Button
          secondary
          title={
            mode === "login" ? "جديد هون؟ اعمل حساب" : "رجوع لتسجيل الدخول"
          }
          onPress={() => {
            setMode(mode === "login" ? "signup" : "login");
            setError("");
            setInfo("");
          }}
          disabled={busy}
        />
        {mode === "login" && (
          <Text style={s.link} onPress={() => setMode("recover")}>
            نسيت كلمة المرور؟
          </Text>
        )}
        <Text style={[s.subtitle, { fontSize: 12, marginTop: 22 }]}>
          نسخة أولية للتجربة. المحادثات ليست مشفّرة من طرف إلى طرف. لا ترسل
          معلومات حسّاسة.
        </Text>
        <Text style={s.link} onPress={onReset}>
          إعداد الاتصال
        </Text>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
