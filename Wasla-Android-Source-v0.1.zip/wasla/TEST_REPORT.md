# Wasla 0.1 — verification record

Date: 2026-09-17.

## Passed

- TypeScript strict checking (`npm run typecheck`).
- Expo Android JavaScript/Hermes export (715 modules). This produces a bundle, **not an APK**.
- Expo native Android project generation (`expo prebuild --platform android --no-install`).
- Executing the complete schema in PGlite/PostgreSQL, with local stand-ins for Supabase auth/storage roles and tables.
- Security tests: non-member conversation/profile/media isolation; sender spoofing denied; membership escalation denied; editing somebody else's message denied; attachment uploader validation; direct conversation deduplication; read markers; blocking and prevention of edits bypassing a block; group owner controls; status visibility and timestamp forgery rejection; deletion tombstones; anonymous RPC rejection.
- Browser UI smoke test at 393×852: connection setup → email login → conversation list → open conversation → send text and render it. **All backend responses in this test were mocked.** No real accounts or messages were created.
- Inspected screenshots in `previews/`: login and conversation. Names/messages are synthetic test fixtures, not real contacts. Desktop test browser lacks some emoji glyphs; Android rendering must be checked on device.

## Build blocker

A native arm64 release APK was attempted using Java 17, Gradle 9.3.1, and Android SDK 36. Dependency resolution failed with HTTP 403 for `org.jetbrains.kotlin:kotlin-serialization:1.9.24` from the configured Maven/Gradle repositories. No APK was produced. The source archive must not be presented as an installable Android app.

The generated `android/` project and build instructions are included so the build can be continued on a machine with dependency access. Native compilation has not been proven successful beyond project generation.

## Not tested / not configured

- No Supabase project, SQL deployment, SMTP provider or real email account was configured.
- No two-device messaging, real Realtime subscription, hosted Storage/RLS integration, Android microphone/camera/file permission flow, video/audio playback, recovery email, physical-device installation, or runtime background behavior was tested.
- Calls, push notifications, E2EE and the other features listed as absent in README are not implemented.

## Repeat checks

```sh
npm ci
npm run typecheck
npm run test:security
```

The optional `tests/ui-smoke.cjs` requires `playwright` installed locally and Chromium (`npx playwright install chromium`). First export with `EXPO_OFFLINE=1 npx expo export --platform web --output-dir web-preview`, then run `node tests/ui-smoke.cjs`. `PLAYWRIGHT_EXECUTABLE_PATH` can select an existing Chromium executable. The script starts a local static server and intercepts all Supabase HTTP requests with fixtures.

## Connection configuration update

The owner supplied a project URL and publishable key, now embedded in src/project.ts. Read-only live checks returned HTTP 200 from Auth settings: email signup enabled, email confirmation required, phone login disabled. The profiles REST endpoint returned HTTP 404/PGRST205: public.profiles absent from schema cache. Schema deployment and email delivery remain unverified; no accounts or messages were created. TypeScript checking passed after the configuration change.
